package com.example.garaje

import java.util.Locale
import java.util.UUID

val FuelType.unit: String get() = if (this == FuelType.ELECTRIC) "kWh" else "L"
val FuelType.consumptionUnit: String get() = if (this == FuelType.ELECTRIC) "kWh/100 km" else "L/100 km"
val FuelType.label: String get() = if (this == FuelType.ELECTRIC) "Eléctrico" else "Gasolina"

fun fmt(value: Double, decimals: Int = 2): String =
    String.format(Locale.getDefault(), "%.${decimals}f", value)

fun fmtInt(value: Int): String = String.format(Locale.getDefault(), "%,d", value)

/** Número de un campo de texto, aceptando coma o punto decimal. */
fun String.num(): Double? = trim().replace(',', '.').toDoubleOrNull()

/** Número para volver a mostrarlo en un campo de texto. */
fun fmtInput(value: Double): String =
    if (value % 1.0 == 0.0) value.toLong().toString() else value.toString()

fun newId(): String = UUID.randomUUID().toString()

fun now(): Long = System.currentTimeMillis()

fun <T> List<T>.upsert(item: T, id: (T) -> String): List<T> {
    val index = indexOfFirst { id(it) == id(item) }
    return if (index < 0) this + item else toMutableList().also { it[index] = item }
}
