package com.example.garaje

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import java.io.File

/**
 * Los datos viven en un fichero JSON local (funciona sin conexión) y se sincronizan
 * con garaje.json en tu Synology. Al sincronizar se fusionan ambos lados por id,
 * gana el registro modificado más tarde, y los borrados se conservan como "deleted".
 */
class Repository(context: Context) {
    private val file = File(context.filesDir, "garaje.json")
    private val prefs = context.getSharedPreferences("sync", Context.MODE_PRIVATE)
    private val json = Json {
        ignoreUnknownKeys = true
        prettyPrint = true
        encodeDefaults = true
    }
    private val webdav = WebDavClient()
    private val syncMutex = Mutex()

    private val _data = MutableStateFlow(load())
    val data: StateFlow<AppData> = _data

    private fun load(): AppData {
        if (!file.exists()) return AppData()
        return try {
            json.decodeFromString(AppData.serializer(), file.readText())
        } catch (e: Exception) {
            // Fichero dañado: lo guardamos aparte y empezamos vacío (se recuperará del NAS al sincronizar)
            runCatching { file.copyTo(File(file.parentFile, "garaje.corrupto.json"), overwrite = true) }
            AppData()
        }
    }

    @Synchronized
    private fun save() {
        val tmp = File(file.parentFile, "garaje.json.tmp")
        tmp.writeText(json.encodeToString(AppData.serializer(), _data.value))
        if (!tmp.renameTo(file)) {
            file.writeText(tmp.readText())
            tmp.delete()
        }
    }

    fun update(transform: (AppData) -> AppData) {
        _data.update(transform)
        save()
    }

    fun settings(): SyncSettings = SyncSettings(
        url = prefs.getString("url", "") ?: "",
        user = prefs.getString("user", "") ?: "",
        password = prefs.getString("password", "") ?: "",
    )

    fun saveSettings(s: SyncSettings) {
        prefs.edit()
            .putString("url", s.url)
            .putString("user", s.user)
            .putString("password", s.password)
            .apply()
    }

    suspend fun sync(): Result<Unit> = withContext(Dispatchers.IO) {
        syncMutex.withLock {
            runCatching {
                val cfg = settings()
                require(cfg.configured) { "Configura la sincronización en Ajustes" }

                var done = false
                var attempts = 0
                while (!done && attempts < 3) {
                    attempts++
                    val remote = webdav.get(cfg)
                    val remoteBody = remote.body
                    if (remoteBody != null) {
                        val remoteData = json.decodeFromString(AppData.serializer(), remoteBody)
                        _data.update { merge(it, remoteData) }
                        save()
                    }
                    val payload = json.encodeToString(AppData.serializer(), _data.value)
                    done = webdav.put(cfg, payload, remote)
                }
                check(done) { "Conflicto al sincronizar, inténtalo de nuevo" }
            }
        }
    }
}
