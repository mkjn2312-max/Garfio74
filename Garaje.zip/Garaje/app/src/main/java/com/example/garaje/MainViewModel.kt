package com.example.garaje

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = Repository(app)

    val data: StateFlow<AppData> = repo.data
    val selectedId = MutableStateFlow<String?>(null)
    val status = MutableStateFlow("Sincronización sin configurar")
    val syncing = MutableStateFlow(false)

    private val _settings = MutableStateFlow(repo.settings())
    val settings: StateFlow<SyncSettings> = _settings

    private var syncAgain = false

    fun syncIfConfigured() {
        if (repo.settings().configured) sync()
    }

    fun sync() {
        if (syncing.value) {
            syncAgain = true // hubo cambios durante la sincronización: repetir al acabar
            return
        }
        viewModelScope.launch {
            syncing.value = true
            do {
                syncAgain = false
                val result = repo.sync()
                status.value = result.fold(
                    onSuccess = {
                        "Sincronizado " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM HH:mm"))
                    },
                    onFailure = { "Error: " + (it.message ?: it.javaClass.simpleName) },
                )
            } while (syncAgain)
            syncing.value = false
        }
    }

    fun saveSettings(s: SyncSettings) {
        repo.saveSettings(s)
        _settings.value = s
    }

    private fun change(transform: (AppData) -> AppData) {
        repo.update(transform)
        syncIfConfigured()
    }

    fun saveVehicle(v: Vehicle) = change { d ->
        d.copy(vehicles = d.vehicles.upsert(v.copy(updatedAt = now())) { it.id })
    }

    fun deleteVehicle(id: String) = change { d ->
        val t = now()
        d.copy(
            vehicles = d.vehicles.map { if (it.id == id) it.copy(deleted = true, updatedAt = t) else it },
            fills = d.fills.map { if (it.vehicleId == id) it.copy(deleted = true, updatedAt = t) else it },
            services = d.services.map { if (it.vehicleId == id) it.copy(deleted = true, updatedAt = t) else it },
        )
    }

    fun saveFill(f: Fill) = change { d ->
        d.copy(fills = d.fills.upsert(f.copy(updatedAt = now())) { it.id })
    }

    fun deleteFill(id: String) = change { d ->
        d.copy(fills = d.fills.map { if (it.id == id) it.copy(deleted = true, updatedAt = now()) else it })
    }

    fun saveService(s: Service) = change { d ->
        d.copy(services = d.services.upsert(s.copy(updatedAt = now())) { it.id })
    }

    fun deleteService(id: String) = change { d ->
        d.copy(services = d.services.map { if (it.id == id) it.copy(deleted = true, updatedAt = now()) else it })
    }
}
