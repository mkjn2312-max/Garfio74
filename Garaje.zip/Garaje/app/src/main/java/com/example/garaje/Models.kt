package com.example.garaje

import kotlinx.serialization.Serializable

@Serializable
enum class FuelType { ELECTRIC, GASOLINE }

@Serializable
data class Vehicle(
    val id: String,
    val name: String,
    val type: FuelType,
    val plate: String = "",
    val updatedAt: Long = 0,
    val deleted: Boolean = false,
)

/** Repostaje (combustible, en litros) o carga (eléctrico, en kWh). */
@Serializable
data class Fill(
    val id: String,
    val vehicleId: String,
    val date: String,          // AAAA-MM-DD
    val odometer: Int,         // km totales del cuentakilómetros
    val quantity: Double,      // litros o kWh
    val totalCost: Double,     // euros
    val full: Boolean = true,  // depósito lleno / carga hasta tu nivel habitual
    val notes: String = "",
    val startLevel: Int? = null, // eléctrico: % de batería al empezar; combustible: nivel en octavos (1..8)
    val endLevel: Int? = null,   // eléctrico: % al terminar; combustible: octavos al terminar
    val updatedAt: Long = 0,
    val deleted: Boolean = false,
)

/** Mantenimiento: revisión, ITV, neumáticos, etc. */
@Serializable
data class Service(
    val id: String,
    val vehicleId: String,
    val date: String,
    val odometer: Int,
    val description: String,
    val cost: Double = 0.0,
    val nextKm: Int? = null,      // km a los que toca la siguiente vez
    val nextDate: String? = null, // fecha de la siguiente vez
    val updatedAt: Long = 0,
    val deleted: Boolean = false,
)

@Serializable
data class AppData(
    val vehicles: List<Vehicle> = emptyList(),
    val fills: List<Fill> = emptyList(),
    val services: List<Service> = emptyList(),
)

/** Fusiona dos conjuntos de datos: gana el registro modificado más recientemente. */
fun merge(a: AppData, b: AppData): AppData = AppData(
    vehicles = mergeById(a.vehicles, b.vehicles, { it.id }, { it.updatedAt }),
    fills = mergeById(a.fills, b.fills, { it.id }, { it.updatedAt }),
    services = mergeById(a.services, b.services, { it.id }, { it.updatedAt }),
)

private fun <T> mergeById(a: List<T>, b: List<T>, id: (T) -> String, ts: (T) -> Long): List<T> {
    val map = LinkedHashMap<String, T>()
    for (x in a + b) {
        val current = map[id(x)]
        if (current == null || ts(x) > ts(current)) map[id(x)] = x
    }
    return map.values.toList()
}
