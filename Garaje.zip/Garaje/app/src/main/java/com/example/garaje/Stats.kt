package com.example.garaje

import java.time.LocalDate
import java.time.temporal.ChronoUnit

/**
 * Tramo entre dos repostajes/cargas "completos" consecutivos.
 * Es el método fiable de consumo: todo lo repostado desde el último lleno
 * (incluido el lleno que cierra el tramo) entre los km recorridos.
 */
data class Segment(val endId: String, val km: Int, val quantity: Double, val cost: Double) {
    val per100: Double get() = quantity / km * 100
    val cost100: Double get() = cost / km * 100
}

data class Due(
    val description: String,
    val kmLeft: Int?,
    val dueDate: LocalDate?,
    val daysLeft: Long?,
) {
    val overdue: Boolean
        get() = (kmLeft != null && kmLeft <= 0) || (daysLeft != null && daysLeft < 0)
}

data class Stats(
    val currentOdo: Int,
    val registeredKm: Int,
    val fillCount: Int,
    val avg: Double?,
    val last: Double?,
    val best: Double?,
    val worst: Double?,
    val avgCost100: Double?,
    val avgUnitPrice: Double?,
    val totalQuantity: Double,
    val energyCost: Double,
    val serviceCost: Double,
    val upcoming: List<Due>,
) {
    val totalCost: Double get() = energyCost + serviceCost
    val costPerKm: Double? get() = if (registeredKm > 0) totalCost / registeredKm else null
}

fun segments(fills: List<Fill>): List<Segment> {
    val sorted = fills.sortedWith(compareBy<Fill>({ it.odometer }, { it.date }))
    val out = mutableListOf<Segment>()
    var startIdx = -1
    var qty = 0.0
    var cost = 0.0
    for ((i, f) in sorted.withIndex()) {
        if (startIdx >= 0) {
            qty += f.quantity
            cost += f.totalCost
        }
        if (f.full) {
            if (startIdx >= 0) {
                val km = f.odometer - sorted[startIdx].odometer
                if (km > 0) out += Segment(f.id, km, qty, cost)
            }
            startIdx = i
            qty = 0.0
            cost = 0.0
        }
    }
    return out
}

fun computeStats(fills: List<Fill>, services: List<Service>, today: LocalDate = LocalDate.now()): Stats {
    val segs = segments(fills)
    val currentOdo = (fills.map { it.odometer } + services.map { it.odometer }).maxOrNull() ?: 0
    val fillOdos = fills.map { it.odometer }
    val registeredKm =
        if (fillOdos.size >= 2) (fillOdos.maxOrNull() ?: 0) - (fillOdos.minOrNull() ?: 0) else 0

    val segKm = segs.sumOf { it.km }
    val avg = if (segKm > 0) segs.sumOf { it.quantity } / segKm * 100 else null
    val avgCost100 = if (segKm > 0) segs.sumOf { it.cost } / segKm * 100 else null
    val per = segs.map { it.per100 }
    val totalQty = fills.sumOf { it.quantity }
    val energyCost = fills.sumOf { it.totalCost }

    val upcoming = services
        .groupBy { it.description.trim().lowercase() }
        .values
        .mapNotNull { group ->
            val latest = group.maxWithOrNull(compareBy<Service>({ it.date }, { it.odometer }))
                ?: return@mapNotNull null
            val kmLeft = latest.nextKm?.let { it - currentOdo }
            val date = latest.nextDate?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
            if (kmLeft == null && date == null) {
                null
            } else {
                Due(
                    description = latest.description.trim(),
                    kmLeft = kmLeft,
                    dueDate = date,
                    daysLeft = date?.let { ChronoUnit.DAYS.between(today, it) },
                )
            }
        }
        .sortedWith(compareByDescending<Due> { it.overdue }.thenBy { it.kmLeft ?: Int.MAX_VALUE })

    return Stats(
        currentOdo = currentOdo,
        registeredKm = registeredKm,
        fillCount = fills.size,
        avg = avg,
        last = per.lastOrNull(),
        best = per.minOrNull(),
        worst = per.maxOrNull(),
        avgCost100 = avgCost100,
        avgUnitPrice = if (totalQty > 0) energyCost / totalQty else null,
        totalQuantity = totalQty,
        energyCost = energyCost,
        serviceCost = services.sumOf { it.cost },
        upcoming = upcoming,
    )
}
