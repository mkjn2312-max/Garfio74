@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.garaje

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import java.time.LocalDate

/** Envoltorio para distinguir "crear nuevo" (item == null) de "editar". */
private class Edit<T>(val item: T?)

// ---------------------------------------------------------------------------------------------
// Pantalla principal
// ---------------------------------------------------------------------------------------------

@Composable
fun GarajeApp(vm: MainViewModel) {
    val data by vm.data.collectAsState()
    val selectedId by vm.selectedId.collectAsState()
    val status by vm.status.collectAsState()
    val syncing by vm.syncing.collectAsState()

    var tab by rememberSaveable { mutableIntStateOf(0) }
    var fillEdit by remember { mutableStateOf<Edit<Fill>?>(null) }
    var serviceEdit by remember { mutableStateOf<Edit<Service>?>(null) }

    val vehicles = data.vehicles.filter { !it.deleted }
    val vehicle = vehicles.firstOrNull { it.id == selectedId } ?: vehicles.firstOrNull()
    val fills = if (vehicle == null) emptyList() else data.fills.filter { it.vehicleId == vehicle.id && !it.deleted }
    val services = if (vehicle == null) emptyList() else data.services.filter { it.vehicleId == vehicle.id && !it.deleted }

    val tabs = listOf("📊" to "Resumen", "⛽" to "Registro", "🔧" to "Gastos", "⚙️" to "Ajustes")

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Garaje") },
                actions = {
                    TextButton(onClick = { vm.sync() }, enabled = !syncing) {
                        Text(if (syncing) "Sincronizando…" else "Sincronizar")
                    }
                },
            )
        },
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, (icon, name) ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Text(icon) },
                        label = { Text(name) },
                    )
                }
            }
        },
        floatingActionButton = {
            if (vehicle != null && tab == 1) {
                ExtendedFloatingActionButton(onClick = { fillEdit = Edit(null) }) {
                    Text(if (vehicle.type == FuelType.ELECTRIC) "+ Carga" else "+ Repostaje")
                }
            } else if (vehicle != null && tab == 2) {
                ExtendedFloatingActionButton(onClick = { serviceEdit = Edit(null) }) {
                    Text("+ Gasto")
                }
            }
        },
    ) { inner ->
        Column(Modifier.padding(inner).fillMaxSize()) {
            when {
                tab == 3 -> SettingsTab(vm, vehicles, status, syncing)
                vehicle == null -> EmptyState { tab = 3 }
                else -> {
                    VehicleSelector(vehicles, vehicle.id) { vm.selectedId.value = it }
                    Text(
                        status,
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(horizontal = 16.dp),
                    )
                    when (tab) {
                        0 -> SummaryTab(vehicle, fills, services)
                        1 -> FillsTab(vehicle, fills) { fillEdit = Edit(it) }
                        else -> ServicesTab(vehicle, services) { serviceEdit = Edit(it) }
                    }
                }
            }
        }
    }

    val fe = fillEdit
    if (fe != null && vehicle != null) {
        FillDialog(
            vehicle = vehicle,
            initial = fe.item,
            onDismiss = { fillEdit = null },
            onSave = { vm.saveFill(it); fillEdit = null },
            onDelete = { vm.deleteFill(it); fillEdit = null },
        )
    }
    val se = serviceEdit
    if (se != null && vehicle != null) {
        ServiceDialog(
            vehicle = vehicle,
            initial = se.item,
            onDismiss = { serviceEdit = null },
            onSave = { vm.saveService(it); serviceEdit = null },
            onDelete = { vm.deleteService(it); serviceEdit = null },
        )
    }
}

@Composable
private fun EmptyState(onGoSettings: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("Aún no tienes ningún vehículo.", style = MaterialTheme.typography.titleMedium)
        Text("Añade tus coches en Ajustes para empezar.", modifier = Modifier.padding(vertical = 8.dp))
        Button(onClick = onGoSettings) { Text("Ir a Ajustes") }
    }
}

@Composable
private fun VehicleSelector(vehicles: List<Vehicle>, selectedId: String, onSelect: (String) -> Unit) {
    Row(
        Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        vehicles.forEach { v ->
            FilterChip(
                selected = v.id == selectedId,
                onClick = { onSelect(v.id) },
                label = { Text((if (v.type == FuelType.ELECTRIC) "⚡ " else "⛽ ") + v.name) },
            )
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Resumen
// ---------------------------------------------------------------------------------------------

@Composable
private fun SummaryTab(vehicle: Vehicle, fills: List<Fill>, services: List<Service>) {
    val s = remember(fills, services) { computeStats(fills, services) }
    val segs = remember(fills) { segments(fills) }
    val unit = vehicle.type.unit
    val cUnit = vehicle.type.consumptionUnit

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Consumo medio", style = MaterialTheme.typography.labelLarge)
                    Text(
                        s.avg?.let { fmt(it, 2) + " " + cUnit } ?: "—",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                    )
                    if (s.avg == null) {
                        Text(
                            "Se calcula entre dos " +
                                (if (vehicle.type == FuelType.ELECTRIC) "cargas completas" else "depósitos llenos") +
                                ". Necesitas al menos dos registros marcados como completos.",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                    val chartValues = segs.map { it.per100 }.takeLast(20)
                    if (chartValues.size >= 2) {
                        ConsumptionChart(chartValues, Modifier.padding(top = 12.dp))
                        Text(
                            "Últimos ${chartValues.size} tramos · mín ${fmt(chartValues.min(), 1)} · máx ${fmt(chartValues.max(), 1)}",
                            style = MaterialTheme.typography.labelSmall,
                        )
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Consumos", style = MaterialTheme.typography.titleMedium)
                    Stat("Último tramo", s.last?.let { fmt(it, 2) + " " + cUnit } ?: "—")
                    Stat("Mejor tramo", s.best?.let { fmt(it, 2) + " " + cUnit } ?: "—")
                    Stat("Peor tramo", s.worst?.let { fmt(it, 2) + " " + cUnit } ?: "—")
                    Stat("Coste cada 100 km", s.avgCost100?.let { fmt(it, 2) + " €" } ?: "—")
                    Stat("Precio medio por $unit", s.avgUnitPrice?.let { fmt(it, 3) + " €/$unit" } ?: "—")
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Kilómetros", style = MaterialTheme.typography.titleMedium)
                    Stat("Cuentakilómetros actual", fmtInt(s.currentOdo) + " km")
                    Stat("Recorridos desde el primer registro", fmtInt(s.registeredKm) + " km")
                    Stat(
                        if (vehicle.type == FuelType.ELECTRIC) "Cargas registradas" else "Repostajes registrados",
                        s.fillCount.toString(),
                    )
                    Stat("Total " + (if (vehicle.type == FuelType.ELECTRIC) "energía" else "combustible"), fmt(s.totalQuantity, 1) + " " + unit)
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Gastos", style = MaterialTheme.typography.titleMedium)
                    Stat(if (vehicle.type == FuelType.ELECTRIC) "Electricidad" else "Combustible", fmt(s.energyCost) + " €")
                    Stat("Mantenimiento y otros", fmt(s.serviceCost) + " €")
                    Stat("Total", fmt(s.totalCost) + " €", emphasize = true)
                    Stat("Coste por km (aprox.)", s.costPerKm?.let { fmt(it, 3) + " €/km" } ?: "—")
                }
            }
        }
        if (s.upcoming.isNotEmpty()) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Próximos mantenimientos", style = MaterialTheme.typography.titleMedium)
                        s.upcoming.forEach { d ->
                            Column(Modifier.padding(vertical = 4.dp)) {
                                Text(d.description, fontWeight = FontWeight.Bold)
                                Text(
                                    dueText(d),
                                    color = if (d.overdue) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
                                    style = MaterialTheme.typography.bodyMedium,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun dueText(d: Due): String {
    val parts = mutableListOf<String>()
    d.kmLeft?.let {
        parts += when {
            it > 0 -> "faltan ${fmtInt(it)} km"
            it == 0 -> "toca ahora"
            else -> "pasado hace ${fmtInt(-it)} km"
        }
    }
    d.dueDate?.let { date ->
        val left = d.daysLeft ?: 0
        parts += if (left >= 0) "el $date (en $left días)" else "el $date (hace ${-left} días)"
    }
    return parts.joinToString(" · ")
}

@Composable
private fun Stat(label: String, value: String, emphasize: Boolean = false) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, modifier = Modifier.weight(1f))
        Text(value, fontWeight = if (emphasize) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
private fun ConsumptionChart(values: List<Double>, modifier: Modifier = Modifier) {
    val lineColor = MaterialTheme.colorScheme.primary
    val gridColor = MaterialTheme.colorScheme.outlineVariant
    Canvas(modifier.fillMaxWidth().height(140.dp)) {
        if (values.size < 2) return@Canvas
        val min = values.min()
        val max = values.max()
        val range = if (max - min > 0) max - min else 1.0
        val w = size.width
        val h = size.height
        drawLine(gridColor, Offset(0f, h), Offset(w, h), strokeWidth = 2f)
        val points = values.mapIndexed { i, v ->
            val frac = ((v - min) / range).toFloat()
            Offset(w * i / (values.size - 1), h - h * frac * 0.9f - h * 0.05f)
        }
        for (i in 0 until points.size - 1) {
            drawLine(lineColor, points[i], points[i + 1], strokeWidth = 5f)
        }
        points.forEach { drawCircle(lineColor, radius = 7f, center = it) }
    }
}

// ---------------------------------------------------------------------------------------------
// Registro de repostajes / cargas
// ---------------------------------------------------------------------------------------------

@Composable
private fun FillsTab(vehicle: Vehicle, fills: List<Fill>, onEdit: (Fill) -> Unit) {
    val segMap = remember(fills) { segments(fills).associateBy { it.endId } }
    val sorted = remember(fills) {
        fills.sortedWith(compareByDescending<Fill> { it.odometer }.thenByDescending { it.date })
    }
    val unit = vehicle.type.unit
    val cUnit = vehicle.type.consumptionUnit

    if (sorted.isEmpty()) {
        Text(
            "Sin registros todavía. Pulsa el botón de abajo para añadir el primero.",
            modifier = Modifier.padding(16.dp),
        )
        return
    }
    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        items(sorted, key = { it.id }) { f ->
            Card(onClick = { onEdit(f) }, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text(
                        "${f.date}  ·  ${fmtInt(f.odometer)} km" + if (f.full) "" else "  (parcial)",
                        fontWeight = FontWeight.Bold,
                    )
                    val unitPrice = if (f.quantity > 0) f.totalCost / f.quantity else 0.0
                    Text("${fmt(f.quantity)} $unit  ·  ${fmt(f.totalCost)} €  ·  ${fmt(unitPrice, 3)} €/$unit")
                    segMap[f.id]?.let { seg ->
                        Text(
                            "Tramo ${fmtInt(seg.km)} km → ${fmt(seg.per100)} $cUnit · ${fmt(seg.cost100)} €/100 km",
                            color = MaterialTheme.colorScheme.primary,
                        )
                    }
                    levelText(f, vehicle.type == FuelType.ELECTRIC)?.let { Text(it) }
                    if (f.notes.isNotBlank()) {
                        Text(f.notes, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun FillDialog(
    vehicle: Vehicle,
    initial: Fill?,
    onDismiss: () -> Unit,
    onSave: (Fill) -> Unit,
    onDelete: (String) -> Unit,
) {
    val ev = vehicle.type == FuelType.ELECTRIC
    var date by remember { mutableStateOf(initial?.date ?: LocalDate.now().toString()) }
    var odo by remember { mutableStateOf(initial?.odometer?.toString() ?: "") }
    var qty by remember { mutableStateOf(initial?.quantity?.let { fmtInput(it) } ?: "") }
    var cost by remember { mutableStateOf(initial?.totalCost?.let { fmtInput(it) } ?: "") }
    var full by remember { mutableStateOf(initial?.full ?: true) }
    var notes by remember { mutableStateOf(initial?.notes ?: "") }
    var startPct by remember { mutableStateOf(if (ev) (initial?.startLevel?.toString() ?: "") else "") }
    var endPct by remember { mutableStateOf(if (ev) (initial?.endLevel?.toString() ?: "") else "") }
    var startEighth by remember { mutableStateOf<Int?>(if (ev) null else initial?.startLevel) }
    var endEighth by remember { mutableStateOf<Int?>(if (ev) null else initial?.endLevel) }

    val parsedDate = runCatching { LocalDate.parse(date.trim()) }.getOrNull()
    val odoV = odo.trim().toIntOrNull()
    val qtyV = qty.num()
    val costV = if (cost.isBlank()) 0.0 else cost.num()
    val startPctV = startPct.trim().toIntOrNull()
    val endPctV = endPct.trim().toIntOrNull()
    val pctOk = !ev || (
        (startPct.isBlank() || (startPctV != null && startPctV in 0..100)) &&
            (endPct.isBlank() || (endPctV != null && endPctV in 0..100)) &&
            (startPctV == null || endPctV == null || endPctV >= startPctV)
        )
    val sE = startEighth
    val eE = endEighth
    val eighthOk = ev || sE == null || eE == null || eE >= sE
    val valid = parsedDate != null && odoV != null && qtyV != null && qtyV > 0 && costV != null &&
        pctOk && eighthOk

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                when {
                    initial != null -> if (ev) "Editar carga" else "Editar repostaje"
                    ev -> "Nueva carga"
                    else -> "Nuevo repostaje"
                }
            )
        },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Field("Fecha (AAAA-MM-DD)", date, { date = it })
                Field("Kilómetros (cuentakilómetros)", odo, { odo = it }, KeyboardType.Number)
                Field(if (ev) "Energía cargada (kWh)" else "Litros", qty, { qty = it }, KeyboardType.Decimal)
                Field("Importe total (€)", cost, { cost = it }, KeyboardType.Decimal)
                if (ev) {
                    Field("Batería al empezar la carga (%)", startPct, { startPct = it }, KeyboardType.Number)
                    Field("Batería al terminar la carga (%)", endPct, { endPct = it }, KeyboardType.Number)
                } else {
                    LevelDropdown("Depósito al llegar", startEighth) { startEighth = it }
                    LevelDropdown("Depósito al terminar", endEighth) {
                        endEighth = it
                        full = it == 8 // 8/8 = depósito lleno
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = full, onCheckedChange = { full = it })
                    Text(if (ev) "Carga completa (hasta tu nivel habitual)" else "Depósito lleno")
                }
                Field(if (ev) "Cargador / lugar (opcional)" else "Gasolinera (opcional)", notes, { notes = it })
                if (initial != null) DeleteButton { onDelete(initial.id) }
            }
        },
        confirmButton = {
            TextButton(
                enabled = valid,
                onClick = {
                    onSave(
                        Fill(
                            id = initial?.id ?: newId(),
                            vehicleId = vehicle.id,
                            date = parsedDate!!.toString(),
                            odometer = odoV!!,
                            quantity = qtyV!!,
                            totalCost = costV!!,
                            full = full,
                            notes = notes.trim(),
                            startLevel = if (ev) startPctV else sE,
                            endLevel = if (ev) endPctV else eE,
                        )
                    )
                },
            ) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}

// ---------------------------------------------------------------------------------------------
// Gastos y mantenimiento
// ---------------------------------------------------------------------------------------------

@Composable
private fun ServicesTab(vehicle: Vehicle, services: List<Service>, onEdit: (Service) -> Unit) {
    val sorted = remember(services) {
        services.sortedWith(compareByDescending<Service> { it.date }.thenByDescending { it.odometer })
    }
    if (sorted.isEmpty()) {
        Text(
            "Sin gastos todavía. Registra aquí revisiones, ITV, neumáticos, seguro, reparaciones…",
            modifier = Modifier.padding(16.dp),
        )
        return
    }
    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item {
            Text(
                "Total gastado en mantenimiento: ${fmt(sorted.sumOf { it.cost })} €",
                fontWeight = FontWeight.Bold,
            )
        }
        items(sorted, key = { it.id }) { s ->
            Card(onClick = { onEdit(s) }, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text(s.description, fontWeight = FontWeight.Bold)
                    Text("${s.date}  ·  ${fmtInt(s.odometer)} km  ·  ${fmt(s.cost)} €")
                    val next = listOfNotNull(
                        s.nextKm?.let { "a los ${fmtInt(it)} km" },
                        s.nextDate?.let { "el $it" },
                    )
                    if (next.isNotEmpty()) {
                        Text(
                            "Próxima vez: " + next.joinToString(" o "),
                            color = MaterialTheme.colorScheme.primary,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ServiceDialog(
    vehicle: Vehicle,
    initial: Service?,
    onDismiss: () -> Unit,
    onSave: (Service) -> Unit,
    onDelete: (String) -> Unit,
) {
    var date by remember { mutableStateOf(initial?.date ?: LocalDate.now().toString()) }
    var odo by remember { mutableStateOf(initial?.odometer?.toString() ?: "") }
    var desc by remember { mutableStateOf(initial?.description ?: "") }
    var cost by remember { mutableStateOf(initial?.cost?.let { fmtInput(it) } ?: "") }
    var nextKm by remember { mutableStateOf(initial?.nextKm?.toString() ?: "") }
    var nextDate by remember { mutableStateOf(initial?.nextDate ?: "") }

    val parsedDate = runCatching { LocalDate.parse(date.trim()) }.getOrNull()
    val odoV = odo.trim().toIntOrNull()
    val costV = if (cost.isBlank()) 0.0 else cost.num()
    val nextKmV = nextKm.trim().toIntOrNull()
    val nextDateV = runCatching { LocalDate.parse(nextDate.trim()) }.getOrNull()
    val nextKmOk = nextKm.isBlank() || nextKmV != null
    val nextDateOk = nextDate.isBlank() || nextDateV != null
    val valid = parsedDate != null && odoV != null && costV != null && desc.isNotBlank() && nextKmOk && nextDateOk

    val suggestions = if (vehicle.type == FuelType.ELECTRIC) {
        listOf("Revisión", "ITV", "Neumáticos", "Frenos", "Seguro", "Reparación", "Lavado")
    } else {
        listOf("Aceite y filtros", "Revisión", "ITV", "Neumáticos", "Frenos", "Seguro", "Reparación", "Lavado")
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Nuevo gasto" else "Editar gasto") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Field("Fecha (AAAA-MM-DD)", date, { date = it })
                Field("Kilómetros (cuentakilómetros)", odo, { odo = it }, KeyboardType.Number)
                Field("Concepto", desc, { desc = it })
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    suggestions.forEach { sug ->
                        AssistChip(onClick = { desc = sug }, label = { Text(sug) })
                    }
                }
                Field("Importe (€)", cost, { cost = it }, KeyboardType.Decimal)
                Text(
                    "Recordatorio (opcional)",
                    style = MaterialTheme.typography.labelLarge,
                    modifier = Modifier.padding(top = 8.dp),
                )
                Field("Próxima vez a los (km)", nextKm, { nextKm = it }, KeyboardType.Number)
                Field("Próxima vez el (AAAA-MM-DD)", nextDate, { nextDate = it })
                if (initial != null) DeleteButton { onDelete(initial.id) }
            }
        },
        confirmButton = {
            TextButton(
                enabled = valid,
                onClick = {
                    onSave(
                        Service(
                            id = initial?.id ?: newId(),
                            vehicleId = vehicle.id,
                            date = parsedDate!!.toString(),
                            odometer = odoV!!,
                            description = desc.trim(),
                            cost = costV!!,
                            nextKm = nextKmV,
                            nextDate = nextDateV?.toString(),
                        )
                    )
                },
            ) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}

// ---------------------------------------------------------------------------------------------
// Ajustes: vehículos y sincronización
// ---------------------------------------------------------------------------------------------

@Composable
private fun SettingsTab(vm: MainViewModel, vehicles: List<Vehicle>, status: String, syncing: Boolean) {
    val settings by vm.settings.collectAsState()
    var url by remember(settings) { mutableStateOf(settings.url) }
    var user by remember(settings) { mutableStateOf(settings.user) }
    var pass by remember(settings) { mutableStateOf(settings.password) }
    var vehicleEdit by remember { mutableStateOf<Edit<Vehicle>?>(null) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text("Vehículos", style = MaterialTheme.typography.titleMedium)
        vehicles.forEach { v ->
            Card(onClick = { vehicleEdit = Edit(v) }, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text(v.name, fontWeight = FontWeight.Bold)
                    Text(v.type.label + if (v.plate.isNotBlank()) " · " + v.plate else "")
                }
            }
        }
        Button(onClick = { vehicleEdit = Edit(null) }) { Text("Añadir vehículo") }

        HorizontalDivider(Modifier.padding(vertical = 8.dp))

        Text("Sincronización con Synology (WebDAV)", style = MaterialTheme.typography.titleMedium)
        Text(
            "Los datos se guardan en este móvil y se copian al fichero garaje.json de la carpeta de tu NAS. " +
                "No se envía nada a ningún otro servidor.",
            style = MaterialTheme.typography.bodySmall,
        )
        Field("URL de la carpeta (ej. https://mi-nas.synology.me:5006/Garaje)", url, { url = it }, KeyboardType.Uri)
        if (url.trim().startsWith("http://", ignoreCase = true)) {
            Text(
                "Conexión sin cifrar: úsala solo en tu red local o por VPN (Tailscale/WireGuard).",
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall,
            )
        }
        Field("Usuario", user, { user = it })
        Field("Contraseña", pass, { pass = it }, password = true)
        Button(
            enabled = !syncing,
            onClick = {
                vm.saveSettings(SyncSettings(url.trim(), user.trim(), pass))
                vm.sync()
            },
        ) { Text("Guardar y sincronizar") }
        Text(status, style = MaterialTheme.typography.bodyMedium)
    }

    val ve = vehicleEdit
    if (ve != null) {
        VehicleDialog(
            initial = ve.item,
            onDismiss = { vehicleEdit = null },
            onSave = { vm.saveVehicle(it); vehicleEdit = null },
            onDelete = { vm.deleteVehicle(it); vehicleEdit = null },
        )
    }
}

@Composable
private fun VehicleDialog(
    initial: Vehicle?,
    onDismiss: () -> Unit,
    onSave: (Vehicle) -> Unit,
    onDelete: (String) -> Unit,
) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var plate by remember { mutableStateOf(initial?.plate ?: "") }
    var type by remember { mutableStateOf(initial?.type ?: FuelType.GASOLINE) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Nuevo vehículo" else "Editar vehículo") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Field("Nombre", name, { name = it })
                Field("Matrícula (opcional)", plate, { plate = it })
                if (initial == null) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = type == FuelType.GASOLINE, onClick = { type = FuelType.GASOLINE })
                        Text("Combustible (litros, L/100 km)")
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = type == FuelType.ELECTRIC, onClick = { type = FuelType.ELECTRIC })
                        Text("Eléctrico (kWh, kWh/100 km)")
                    }
                } else {
                    Text("Tipo: " + initial.type.label, modifier = Modifier.padding(vertical = 8.dp))
                    DeleteButton("Pulsa otra vez: borra también todos sus registros") { onDelete(initial.id) }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = name.isNotBlank(),
                onClick = {
                    onSave(
                        Vehicle(
                            id = initial?.id ?: newId(),
                            name = name.trim(),
                            type = type,
                            plate = plate.trim(),
                        )
                    )
                },
            ) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}

// ---------------------------------------------------------------------------------------------
// Componentes comunes
// ---------------------------------------------------------------------------------------------

@Composable
private fun Field(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    keyboard: KeyboardType = KeyboardType.Text,
    password: Boolean = false,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = if (password) KeyboardType.Password else keyboard),
        visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
    )
}

@Composable
private fun LevelDropdown(label: String, value: Int?, onChange: (Int) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text(label + ": " + (value?.let { "$it/8" } ?: "elegir") + "  ▾")
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            (1..8).forEach { n ->
                DropdownMenuItem(
                    text = { Text("$n/8") },
                    onClick = {
                        onChange(n)
                        expanded = false
                    },
                )
            }
        }
    }
}

private fun levelText(f: Fill, ev: Boolean): String? {
    val s = f.startLevel
    val e = f.endLevel
    if (s == null && e == null) return null
    val suffix = if (ev) "%" else "/8"
    val name = if (ev) "Batería" else "Depósito"
    val a = if (s != null) "$s$suffix" else "?"
    val b = if (e != null) "$e$suffix" else "?"
    val extra = if (ev && s != null && e != null) " (+${e - s} %)" else ""
    return "$name $a → $b$extra"
}

@Composable
private fun DeleteButton(warning: String = "Pulsa otra vez para confirmar", onConfirm: () -> Unit) {
    var armed by remember { mutableStateOf(false) }
    TextButton(onClick = { if (armed) onConfirm() else armed = true }) {
        Text(if (armed) warning else "Eliminar", color = MaterialTheme.colorScheme.error)
    }
}
