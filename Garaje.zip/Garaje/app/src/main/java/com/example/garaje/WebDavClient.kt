package com.example.garaje

import okhttp3.Credentials
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.util.concurrent.TimeUnit

data class SyncSettings(
    val url: String = "",
    val user: String = "",
    val password: String = "",
) {
    val configured: Boolean get() = url.isNotBlank() && user.isNotBlank()
}

/** Cliente WebDAV mínimo: lee y escribe un único fichero garaje.json en una carpeta del NAS. */
class WebDavClient {
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    class Remote(val exists: Boolean, val body: String?, val etag: String?)

    private fun fileUrl(cfg: SyncSettings) = cfg.url.trim().trimEnd('/') + "/garaje.json"

    private fun builder(cfg: SyncSettings): Request.Builder = try {
        Request.Builder()
            .url(fileUrl(cfg))
            .header("Authorization", Credentials.basic(cfg.user, cfg.password, Charsets.UTF_8))
    } catch (e: IllegalArgumentException) {
        throw IOException("La URL no es válida (ejemplo: https://mi-nas.synology.me:5006/Garaje)")
    }

    private fun describe(code: Int): String = when (code) {
        401 -> "Usuario o contraseña incorrectos"
        403 -> "Sin permisos en esa carpeta"
        404 -> "No se encuentra la ruta en el NAS"
        409 -> "La carpeta no existe: créala antes en File Station"
        else -> "Error HTTP $code"
    }

    fun get(cfg: SyncSettings): Remote {
        val request = builder(cfg).get().build()
        http.newCall(request).execute().use { r ->
            return when {
                r.code == 404 -> Remote(false, null, null)
                r.isSuccessful -> {
                    val text = r.body?.string()
                    Remote(true, text?.takeIf { it.isNotBlank() }, r.header("ETag"))
                }
                else -> throw IOException(describe(r.code))
            }
        }
    }

    /** Devuelve false si otro dispositivo modificó el fichero mientras tanto (412). */
    fun put(cfg: SyncSettings, content: String, remote: Remote): Boolean {
        val b = builder(cfg).put(content.toRequestBody("application/json; charset=utf-8".toMediaType()))
        val etag = remote.etag
        if (remote.exists && etag != null && !etag.startsWith("W/")) {
            b.header("If-Match", etag)
        }
        http.newCall(b.build()).execute().use { r ->
            return when {
                r.code == 412 -> false
                r.isSuccessful -> true
                else -> throw IOException(describe(r.code))
            }
        }
    }
}
