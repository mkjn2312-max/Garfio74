# Garaje — control privado de coches (Android 16, sincroniza con tu Synology)

App personal para llevar varios vehículos (eléctrico + combustible: gasolina o diésel): repostajes/cargas, consumos,
gastos de mantenimiento con recordatorios y gráfica de consumo. Sin cuentas, sin anuncios, sin
servidores de terceros. Los datos están en el móvil y se copian a un fichero `garaje.json` en tu NAS.

## Qué hace

- **Varios vehículos**: eléctrico (kWh, kWh/100 km) y combustible (litros, L/100 km).
- **Registro**: fecha, km del cuentakilómetros, litros/kWh, importe, lleno/completo, lugar.
  Eléctrico: % de batería al empezar y al terminar la carga. Combustible: nivel del depósito
  al llegar y al terminar (desplegable de 1/8 a 8/8; 8/8 marca depósito lleno).
- **Consumo** por tramos entre dos llenos/cargas completas (método Fuelio): media, último, mejor, peor,
  coste cada 100 km, precio medio por litro/kWh, gráfica de los últimos 20 tramos.
- **Gastos y mantenimiento**: concepto, importe, y recordatorio "próxima vez a los X km / el día Y".
  El Resumen avisa de lo que falta o ya está pasado.
- **Sincronización WebDAV** con tu Synology: al abrir la app, al guardar y con el botón Sincronizar.
  Se fusionan los cambios de varios móviles (gana el registro modificado más tarde).
  Funciona sin conexión; se sincroniza cuando vuelve.

## 1. Preparar el Synology (una vez)

1. Centro de paquetes → instala **WebDAV Server**. Actívalo: HTTP 5005 y/o HTTPS 5006.
2. File Station → crea una carpeta compartida, por ejemplo `Garaje`.
3. Panel de control → Usuario → crea un usuario `garaje` **solo con permiso de lectura/escritura en esa carpeta**
   (y con permiso de uso de la aplicación WebDAV Server).
4. URL que pondrás en la app: `https://TU-DOMINIO:5006/Garaje`
   (en red local: `http://192.168.x.x:5005/Garaje`).

**Acceso desde fuera de casa** (elige uno):
- **Tailscale** en el NAS y en los móviles (lo más sencillo y seguro; URL `http://100.x.x.x:5005/Garaje`).
- **DDNS de Synology + certificado Let's Encrypt + reenvío del puerto 5006** en el router.
- Ojo: **QuickConnect no sirve para WebDAV**.
- Un certificado autofirmado hará que Android rechace la conexión HTTPS; usa Let's Encrypt o VPN.

## 2. Compilar (Android Studio)

1. Descomprime el ZIP y abre la carpeta `Garaje` con **Android Studio** (File → Open).
2. Espera al "Gradle sync" (descarga dependencias; necesita internet y un JDK 17+, que Android Studio incluye).
   Si te propone actualizar la versión de Gradle/AGP/Kotlin, acepta ("Update").
3. Menú **Build → Build APK(s)**. El APK queda en `app/build/outputs/apk/debug/app-debug.apk`.
4. Pásalo al móvil (cable, Drive, etc.) e instálalo permitiendo "instalar apps desconocidas" para esa app.
   O con el móvil en modo desarrollador y depuración USB, pulsa ▶ Run.
5. Para el segundo dispositivo, instala el mismo APK.

## 3. Configurar la app

Ajustes → añade tus 3 vehículos → rellena URL, usuario y contraseña → "Guardar y sincronizar".
En el segundo móvil pon los mismos datos de sincronización y aparecerá todo.

## Notas

- Fechas en formato `AAAA-MM-DD`. Decimales con coma o punto.
- Para que el consumo se calcule necesitas ≥2 registros marcados como completos.
  En el eléctrico, "completa" = cargas hasta tu nivel habitual (p. ej. 80 %).
- La contraseña del NAS se guarda en el almacenamiento privado de la app (no se hace copia en Google).
- Si algo falla, el mensaje de estado en Ajustes dice el motivo (usuario incorrecto, carpeta inexistente…).
- La copia de seguridad es el propio `garaje.json` de tu NAS: puedes incluirlo en Hyper Backup.
